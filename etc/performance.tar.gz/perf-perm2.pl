#!/usr/bin/perl

use strict;

my @x = ();
my @y = ();

my $max = 50;

my $ins = $ARGV[0];

use Data::Dumper;
use Chart::Gnuplot;
use Capture::Tiny qw/capture/;

for(my $i = 1; $i < $max; $i++) {
    for(my $j = 1; $j < $max; $j++) {
        my ($stdout, $stderr) = capture {
            `echo -n "mov r5, $i\\nmov r6, $i\\n$ins r5, r6\\n" | ~/.asmbf/bfasm > perf2-$ins.b`;
            `~/.asmbf/bfi -c perf2-$ins.b`;
        };

        $stderr =~ m/[0-9]+/;
        my @z = (int($i), int($j), int($&));
        push @x, \@z;
    }

    push @x, \@y;
}

my $chart = Chart::Gnuplot->new(
    output => "$ins-2.png",
    title  => "cycles taken by $ins in the 2nd part of the permagen",
    xlabel => 'opr1',
    bg => 'white',
    ylabel => 'opr2'
);
$chart->set(pm3d => 'map');
my $dataSet = Chart::Gnuplot::DataSet->new(
    points => \@x,
);

$chart->plot3d($dataSet);

open(FH, '>', "$ins-2.csv") or die $!;

print FH "opr1,opr2,cycles\n";

for(my $a = 0; $a < $max * ($max); $a++) {
    print FH $x[$a][0] . "," . $x[$a][1] . "," . $x[$a][2] . "\n";
}

close FH;

`rm -f perf2-$ins.b`
